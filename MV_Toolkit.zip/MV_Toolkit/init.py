import nuke
import sys
import os

# Add MV_Tools to path
mv_path = os.path.dirname(__file__)
if mv_path not in sys.path:
    sys.path.append(mv_path)

print("MV Tools initializing...")

import mv_writepro
import mv_project_builder

print("MV Tools loaded")