import os
import nuke

# ============================================================
# CREATE SHOT STRUCTURE
# ============================================================

def create_shot_structure(base_path, project_code, shot_number):

    shot = f"{project_code}{shot_number:03d}"
    shot_root = os.path.join(base_path, project_code, shot)

    folders = [

        # publish
        "publish/comp/final",
        "publish/comp/precomp",
        "publish/comp/dailies",

        "publish/plates/cleanplate",
        "publish/plates/main/undistorted",
        "publish/plates/main/denoise",
        "publish/plates/main/conformed",

        "publish/plates/onsetdata/hdr",
        "publish/cam/track",

        # work
        "work/comp",
        "work/cg",
        "work/matchmove",
        "work/preprod",
    ]

    for f in folders:
        os.makedirs(os.path.join(shot_root, f), exist_ok=True)


# ============================================================
# SAVE INITIAL SCRIPT
# ============================================================

def save_initial_script(base_path, project, shot_number, artist):

    shot = f"{project}{shot_number:03d}"

    comp_folder = os.path.join(
        base_path,
        project,
        shot,
        "work",
        "comp"
    )

    artist = artist.lower().replace(" ", "")

    filename = f"{shot}_comp_main_{artist}_slap_v001.nk"
    full_path = os.path.join(comp_folder, filename)

    # Only save if script is empty
    if nuke.root().name() == "Root":
        nuke.scriptSaveAs(full_path, overwrite=1)
        print("SCRIPT CREATED:", full_path)

    return full_path


# ============================================================
# MAIN TOOL
# ============================================================

def build_project():

    panel = nuke.Panel("MV Project Builder")

    panel.addEnumerationPulldown(
        "Mode",
        "create_project open_latest open_version"
    )

    panel.addSingleLineInput("Project Code (RD)", "RD")
    panel.addSingleLineInput("Base Path", "C:/Users/vikin/Desktop")
    panel.addSingleLineInput("Shot Number (10,20...)", "10")
    panel.addSingleLineInput("End Shot (create only)", "50")
    panel.addSingleLineInput("Artist Name", "mathias")

    if not panel.show():
        return

    mode = panel.value("Mode")
    project = panel.value("Project Code (RD)")
    base = panel.value("Base Path")
    artist = panel.value("Artist Name")

    shot_num = int(panel.value("Shot Number (10,20...)"))
    end = int(panel.value("End Shot (create only)"))

    project_root = os.path.join(base, project)

    # ============================================================
    # CREATE PROJECT
    # ============================================================

    if mode == "create_project":

        for i in range(shot_num, end + 1, 10):
            create_shot_structure(base, project, i)

        save_initial_script(base, project, shot_num, artist)

        nuke.message(f"Project Created:\n{project}")
        return

    # ============================================================
    # OPEN SHOT
    # ============================================================

    shot = f"{project}{shot_num:03d}"

    comp_folder = os.path.join(
        project_root,
        shot,
        "work",
        "comp"
    )

    if not os.path.exists(comp_folder):
        nuke.message("Shot does not exist")
        return

    nk_files = sorted([
        f for f in os.listdir(comp_folder)
        if f.endswith(".nk")
    ])

    if not nk_files:
        nuke.message("No comp scripts found")
        return

    # ------------------------------------------------------------
    # OPEN LATEST
    # ------------------------------------------------------------

    if mode == "open_latest":
        path = os.path.join(comp_folder, nk_files[-1])
        nuke.scriptOpen(path)
        return

    # ------------------------------------------------------------
    # OPEN VERSION SELECT
    # ------------------------------------------------------------

    if mode == "open_version":

        version_panel = nuke.Panel(f"Select Version ({shot})")

        version_panel.addEnumerationPulldown(
            "Version",
            " ".join(nk_files)
        )

        if not version_panel.show():
            return

        selected = version_panel.value("Version")
        path = os.path.join(comp_folder, selected)

        nuke.scriptOpen(path)