import nuke
import os
import re
import time

# ============================================================
# GIZMO PATH (PORTABLE)
# ============================================================

def get_gizmo_path():
    return os.path.join(os.path.dirname(__file__), "gizmos", "MV_WritePro.nk")


# ============================================================
# PROJECT CONTEXT
# ============================================================

def get_project_context():

    script_path = nuke.root().name()

    if script_path == "Root":
        return None, None, None

    script_path = script_path.replace("\\", "/")
    parts = script_path.split("/")

    try:
        shot = parts[-4]
        project = parts[-5]
        project_root = "/".join(parts[:-4])
    except:
        return None, None, None

    return project_root, project, shot


# ============================================================
# AUTO NAMING
# ============================================================

def sanitize(text):
    return re.sub(r"[^a-zA-Z0-9_]", "", text.replace(" ", "_")).lower()


def auto_build_name(node):

    parts = [
        sanitize(node["shot_name"].value()),
        sanitize(node["output_type"].value())
    ]

    for key in ["task", "descriptor", "artist"]:
        val = sanitize(node[key].value())
        if val:
            parts.append(val)

    return "_".join(parts)


# ============================================================
# CREATE NODE
# ============================================================

def create_writepro():

    try:
        nuke.nodePaste(get_gizmo_path())
        node = nuke.selectedNode()
    except Exception as e:
        nuke.message(f"Could not create MV_WritePro:\n{e}")
        return None

    project_root, project, shot = get_project_context()

    if project_root and "project_path" in node.knobs():
        node["project_path"].setValue(project_root)

    if shot and "shot_name" in node.knobs():
        node["shot_name"].setValue(shot)

    update_write(node)

    return node


# ============================================================
# VERSION
# ============================================================

def get_next_version(folder):

    if not os.path.exists(folder):
        return 1

    versions = []

    for f in os.listdir(folder):
        m = re.match(r"v(\d{3})", f)
        if m:
            versions.append(int(m.group(1)))

    return max(versions) + 1 if versions else 1


# ============================================================
# FRAME RANGE
# ============================================================

def get_frame_range(node):

    mode = node["frame_mode"].value()

    if mode == "global":
        return int(nuke.root()["first_frame"].value()), int(nuke.root()["last_frame"].value())

    elif mode == "input":
        inp = node.input(0)
        if not inp:
            nuke.message("No input connected")
            return None, None
        return int(inp.firstFrame()), int(inp.lastFrame())

    else:
        return int(node["frame_start"].value()), int(node["frame_end"].value())


# ============================================================
# FILENAME
# ============================================================

def build_filename(node, version_str):
    return f"{auto_build_name(node)}_{version_str}.####"


# ============================================================
# PATH
# ============================================================

def build_path(node):

    project_root, _, shot = get_project_context()

    if not project_root:
        nuke.message("Script not inside pipeline structure")
        return ""

    routing = {
        "comp": ["publish", "comp", "final"],
        "precomp": ["publish", "comp", "precomp"],
        "plate": ["publish", "plates", "main"],
        "cleanplate": ["publish", "plates", "cleanplate"],
        "denoise": ["publish", "plates", "main", "denoise"],
        "undistort": ["publish", "plates", "main", "undistorted"],
        "cam": ["publish", "cam", "track"]
    }

    category = node["output_type"].value()

    if category not in routing:
        nuke.message(f"Invalid output type: {category}")
        return ""

    base_folder = os.path.join(project_root, *routing[category], shot)

    if node["auto_version"].value():
        version = get_next_version(base_folder)
        node["version"].setValue(version)
    else:
        version = max(1, int(node["version"].value()))

    version_str = f"v{version:03d}"

    folder = os.path.join(base_folder, version_str)

    internal = node.node("internal_write")
    if not internal:
        nuke.message("Internal write node missing")
        return ""

    ext = internal["file_type"].value()
    filename = build_filename(node, version_str)

    return os.path.join(folder, f"{filename}.{ext}").replace("\\", "/")


# ============================================================
# ACES SETTINGS
# ============================================================

def apply_aces_settings(node):

    internal = node.node("internal_write")
    if not internal:
        return

    ft = internal["file_type"].value().lower()

    try:
        if ft == "exr":
            internal["colorspace"].setValue("linear")
            internal["raw"].setValue(True)
            internal["premultiplied"].setValue(False)

        elif ft in ["png", "jpg", "jpeg"]:
            internal["colorspace"].setValue("sRGB")
            internal["raw"].setValue(False)
            internal["premultiplied"].setValue(True)

        elif ft in ["mov", "mp4"]:
            internal["colorspace"].setValue("rec709")
            internal["raw"].setValue(False)
            internal["premultiplied"].setValue(True)

    except Exception as e:
        print("ACES ERROR:", e)


# ============================================================
# VALIDATION
# ============================================================

def validate_before_render(node):

    errors = []

    if not node["shot_name"].value().strip():
        errors.append("Shot name missing")

    if not node["artist"].value().strip():
        errors.append("Artist missing")

    if not get_project_context()[0]:
        errors.append("Not inside pipeline")

    if None in get_frame_range(node):
        errors.append("Invalid frame range")

    if not build_path(node):
        errors.append("Invalid path")

    if errors:
        nuke.message("🚫 RENDER BLOCKED:\n\n" + "\n".join(f"- {e}" for e in errors))
        return False

    return True


# ============================================================
# RENDER
# ============================================================

def render(node):

    if not validate_before_render(node):
        return

    start, end = get_frame_range(node)
    total = max(1, end - start + 1)

    path = build_path(node)

    folder = os.path.dirname(path)
    os.makedirs(folder, exist_ok=True)

    write = node.node("internal_write")
    write["file"].setValue(path)

    apply_aces_settings(node)

    node["status"].setValue("🔵 Rendering...")
    node["progress"].setValue(0)

    t0 = time.time()

    for i, f in enumerate(range(start, end + 1)):
        nuke.execute(write, f, f)

        p = int(((i + 1) / total) * 100)
        node["progress"].setValue(p)
        node["status"].setValue(f"🔵 Rendering... {p}%")

        nuke.executeInMainThread(lambda: None)

    node["progress"].setValue(100)
    node["status"].setValue(f"🟢 Done ({round(time.time()-t0,2)}s)")

    nuke.message(f"Render complete:\n{path}")


# ============================================================
# UPDATE
# ============================================================

def update_write(node):

    path = build_path(node)

    if not path:
        return

    internal = node.node("internal_write")
    if internal:
        internal["file"].setValue(path)

    apply_aces_settings(node)

    if "filepath" in node.knobs():
        node["filepath"].setValue(path)

    node["status"].setValue("Ready")


# ============================================================
# KNOB CHANGE
# ============================================================

def knob_changed():

    node = nuke.thisNode()
    knob = nuke.thisKnob()

    if knob.name() in ["output_type","shot_name","task","descriptor","artist","version","auto_version"]:
        update_write(node)

    if knob.name() == "file_type":
        apply_aces_settings(node)


# ============================================================
# VERSION LOADER
# ============================================================

def create_read_from_writepro():

    node = nuke.selectedNode()

    if not node or not node.knob("filepath"):
        nuke.message("Select MV_WritePro node")
        return

    path = node["filepath"].value()
    if not path:
        nuke.message("No render found")
        return

    version_folder = os.path.dirname(path)
    base_folder = os.path.dirname(version_folder)

    if not os.path.exists(base_folder):
        nuke.message("Render folder missing")
        return

    versions = sorted([f for f in os.listdir(base_folder) if re.match(r"v\d{3}", f)])

    if not versions:
        nuke.message("No versions found")
        return

    latest = versions[-1]

    filename = os.path.basename(path)
    latest_filename = re.sub(r"v\d{3}", latest, filename)

    latest_folder = os.path.join(base_folder, latest)
    latest_path = os.path.join(latest_folder, latest_filename).replace("\\", "/")

    read = nuke.createNode("Read")
    read["file"].setValue(latest_path)

    print("Loaded latest:", latest_path)