import nuke
import mv_writepro
import mv_project_builder

if nuke.env.get("gui"):

    toolbar = nuke.menu("Nodes")
    main_menu = nuke.menu("Nuke")

    # PROJECT BUILDER
    main_menu.addCommand(
        "MV Tools/Project Builder",
        "mv_project_builder.build_project()"
    )

    # WRITEPRO
    toolbar.addCommand(
        "MV Tools/MV WritePro",
        "mv_writepro.create_writepro()",
        "shift+w"
    )

    # VERSION LOADER
    main_menu.addCommand(
        "MV Tools/Read Latest Render",
        "mv_writepro.create_read_from_writepro()",
        "shift+r"
    )